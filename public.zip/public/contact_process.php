<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';
    $packageName = $_POST['packageName'] ?? '';
    $packagePrice = $_POST['packagePrice'] ?? '0';

    // Database connection parameters
    $servername = "localhost";       // or your server name
    $username   = "your_db_user";    // your DB username
    $password   = "your_db_pass";    // your DB password
    $dbname     = "your_db_name";    // your DB name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert into the "contacts" table (make sure it exists)
    $sql = "INSERT INTO contacts (name, email, message, package_name, package_price)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters and execute
    $stmt->bind_param("ssssd", $name, $email, $message, $packageName, $packagePrice);

    if ($stmt->execute()) {
        echo "Your message has been sent successfully!";
        // Optionally redirect to a "thank you" page
        // header("Location: thank_you.html");
        // exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close resources
    $stmt->close();
    $conn->close();
}
?>


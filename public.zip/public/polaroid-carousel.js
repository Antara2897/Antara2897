(function(){
    const track = document.getElementById('polaroid-track');
    const dotsWrap = document.getElementById('polaroid-dots');
    if(!track) return;
  
    const tiltAngles = [-14, 6, 16, -9, 12, -6, 18];
    const root = track.closest('.polaroid-carousel');
    const autoplay = root?.dataset.autoplay === 'true';
    const interval = parseInt(root?.dataset.interval || '4500', 10);
  
    // --- Load image list from JSON ---
    async function loadImages(){
      try {
        const res = await fetch('images.json', { cache: 'no-store' });
        if(!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if(!data || !Array.isArray(data.images) || data.images.length === 0){
          throw new Error('No images in JSON');
        }
        return data.images;
      } catch (err){
        console.warn('[polaroid-carousel] Falling back to defaults:', err?.message || err);
        // Fallback list so the carousel still renders
        return [
          'images/IMG_4041.JPG',
          'images/IMG_4041.JPG',
          'images/IMG_4041.JPG'
        ];
      }
    }
  
    // --- Build DOM from an image array ---
    function build(images){
      const slides = images.map((src, i) => {
        const el = document.createElement('div');
        el.className = 'polaroid-slide';
        el.style.setProperty('--tilt', (tiltAngles[i % tiltAngles.length]) + 'deg');
  
        const img = document.createElement('img');
        img.src = src;
        img.alt = 'Portfolio ' + (i+1);
        el.appendChild(img);
  
        track.appendChild(el);
        return el;
      });
  
      const dots = images.map((_, i) => {
        const b = document.createElement('button');
        b.className = 'polaroid-dot';
        b.setAttribute('aria-label', 'Go to slide ' + (i+1));
        b.addEventListener('click', () => goTo(i));
        dotsWrap.appendChild(b);
        return b;
      });
  
      let index = 0;
      let timer = null;
  
      function render(){
        slides.forEach((s, i) => {
          s.classList.remove('is-active','is-prev','is-next');
          if(i === index) s.classList.add('is-active');
          else if(i === (index - 1 + slides.length) % slides.length) s.classList.add('is-prev');
          else if(i === (index + 1) % slides.length) s.classList.add('is-next');
        });
        dots.forEach((d, i) => d.classList.toggle('is-active', i === index));
      }
  
      function goTo(i){
        index = (i + slides.length) % slides.length;
        render();
      }
  
      function next(){ goTo(index + 1) }
      function prev(){ goTo(index - 1) }
  
      function start(){ if(autoplay){ stop(); timer = setInterval(next, interval); } }
      function stop(){ if(timer){ clearInterval(timer); timer = null; } }
  
      // UI + interactions
      const prevBtn = root.querySelector('.polaroid-prev');
      const nextBtn = root.querySelector('.polaroid-next');
      prevBtn.addEventListener('click', () => { prev(); start(); });
      nextBtn.addEventListener('click', () => { next(); start(); });
  
      // Pause on hover/focus
      root.addEventListener('mouseenter', stop);
      root.addEventListener('mouseleave', start);
      root.addEventListener('focusin', stop);
      root.addEventListener('focusout', start);
  
      // Swipe
      let touchStartX = 0;
      root.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].screenX; }, {passive:true});
      root.addEventListener('touchend', e => {
        const dx = e.changedTouches[0].screenX - touchStartX;
        if(Math.abs(dx) > 40){ if(dx < 0) next(); else prev(); start(); }
      });
  
      // init
      render();
      start();
    }
  
    // Bootstrap
    loadImages().then(build);
  })();
(function(){
    const grid = document.getElementById('products-grid');
    const pills = Array.from(document.querySelectorAll('.products-toolbar .pill'));
    const search = document.getElementById('product-search');
    const params = new URLSearchParams(window.location.search);
    const initial = (params.get('category') || 'all').toLowerCase();
  
    // Load from JSON with graceful fallback to inline samples
    async function loadProducts(){
      try {
        const res = await fetch('products.json', { cache: 'no-store' });
        if(!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if(!data || !Array.isArray(data.products)) throw new Error('Malformed products.json');
        return data.products;
      } catch (err){
        console.warn('[products] Falling back to samples:', err?.message || err);
        return [
          { title:'Bold Urban Logo', category:'logos', image:'images/logo_01.jpg', tags:['Vector','Monogram'] },
          { title:'Concert Night Flyer', category:'flyers', image:'images/flyer_1.jpg', tags:['A4','Neon'] },
          { title:'Minimal Luxe Business Card', category:'business-cards', image:'images/menu_1.jpg', tags:['Foil','Matte'] },
          { title:'Graffiti Sticker Pack', category:'stickers', image:'images/logo_7.JPG', tags:['Die‑cut','Vinyl'] },
          { title:'Mixtape Cover Art', category:'music-covers', image:'images/flyer_7.jpeg', tags:['Hip‑Hop','Urban'] },
          { title:'Instagram Banner Set', category:'social', image:'images/logo_10.JPG', tags:['Story','Highlight'] }
        ];
      }
    }
  
    function label(key){
      const map = {
        'logos':'Logos', 'flyers':'Flyers', 'business-cards':'Business Cards',
        'stickers':'Stickers', 'music-covers':'Music Covers', 'social':'IG Highlights & Banners'
      };
      return map[key] || key;
    }
  
    function productCard(p){
      const tags = (p.tags||[]).map(t => `<span class="tag">${t}</span>`).join('');
      return `
        <article class="product-card" data-category="${p.category}" data-title="${p.title}">
          <div class="product-media">
            <img loading="lazy" src="${p.image}" alt="${p.title}" />
          </div>
          <div class="product-body">
            <h3 class="product-title">${p.title}</h3>
            <div class="product-meta">Category: ${label(p.category)}</div>
            <div class="product-tags">${tags}</div>
          </div>
        </article>`;
    }
  
    function render(products){
      grid.innerHTML = products.map(productCard).join('');
    }
  
    function setActivePill(key){
      pills.forEach(p => p.classList.toggle('active', p.dataset.filter === key));
      pills.forEach(p => p.setAttribute('aria-pressed', p.dataset.filter === key ? 'true' : 'false'));
    }
  
    function filterCards(){
      const key = pills.find(p => p.classList.contains('active'))?.dataset.filter || 'all';
      const q = (search.value || '').trim().toLowerCase();
  
      Array.from(grid.children).forEach(card => {
        const cat = card.dataset.category;
        const title = (card.dataset.title || '').toLowerCase();
        const matchCat = key === 'all' || cat === key;
        const matchText = !q || title.includes(q);
        const show = matchCat && matchText;
        card.style.display = show ? '' : 'none';
      });
    }
  
    // Bind pills
    pills.forEach(p => p.addEventListener('click', () => {
      pills.forEach(x => x.classList.remove('active'));
      p.classList.add('active');
      const key = p.dataset.filter;
      setActivePill(key);
      const url = new URL(window.location);
      if(key === 'all') url.searchParams.delete('category'); else url.searchParams.set('category', key);
      window.history.replaceState({}, '', url);
      filterCards();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }));
  
    search.addEventListener('input', filterCards);
  
    // Bootstrap
    loadProducts().then(products => {
      render(products);
      const has = pills.find(p => p.dataset.filter === initial) ? initial : 'all';
      pills.forEach(x => x.classList.toggle('active', x.dataset.filter === has));
      setActivePill(has);
      filterCards();
    });
  })();
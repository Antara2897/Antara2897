// public/app.js
document.addEventListener('DOMContentLoaded', function () {
    // === 1) MOBILE MENU TOGGLE ===
    const menuToggle = document.querySelector('#mobile-menu');
    const menuLinks = document.querySelector('.navbar__menu');

    menuToggle.addEventListener('click', function () {
        menuLinks.classList.toggle('active');
    });

    // Optional: Close menu when clicking outside
    document.addEventListener('click', function (event) {
        if (!menuToggle.contains(event.target) && !menuLinks.contains(event.target)) {
            menuLinks.classList.remove('active');
        }
    });
});

// === 2) CAROUSEL HANDLING (if still in use) ===
const carouselIndices = {
    logos: 0,
    flyers: 0,
    menus: 0,
    'motion flyer': 0
  };
  
  function moveCarousel(type, direction) {
    const container = document.querySelector(`.carousel--${type} .carousel__container`);
    const items = container.querySelectorAll('.carousel__item');
    const total = items.length;
  
    carouselIndices[type] += direction;
  
    if (carouselIndices[type] < 0) {
      carouselIndices[type] = total - 1;
    } else if (carouselIndices[type] >= total) {
      carouselIndices[type] = 0;
    }
  
    const translateX = -carouselIndices[type] * 100;
    container.style.transform = `translateX(${translateX}%)`;
  }

// === 3) PACKAGE SELECTION & REDIRECT ===
document.addEventListener('DOMContentLoaded', function () {
    const packageButtons = document.querySelectorAll('.package .button');

    // When user clicks "Select" on a package
    packageButtons.forEach(button => {
        button.addEventListener('click', function () {
            const packageName = this.parentElement.querySelector('h3').innerText;
            localStorage.setItem('selectedPackage', packageName);

            // Instead of going to transaction.html, go to contact.html
            // We can also pass via URL if desired, or just rely on localStorage.
            window.location.href = 'contact.html';
            // OR, if you want to pass price too, do something like:
            // window.location.href = `contact.html?package=${encodeURIComponent(packageName)}&price=100`;
        });
    });

    // If we still want to retrieve the selected package on contact.html
    // we might do that in contact.html (via a script):
    // document.addEventListener('DOMContentLoaded', function() {
    //   const selectedPackage = localStorage.getItem('selectedPackage');
    //   // populate hidden input or show on screen
    // });


 
});



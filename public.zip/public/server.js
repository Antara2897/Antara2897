// server.js

const container = carousel.querySelector('.carousel__container');
const items = carousel.querySelectorAll('.carousel__item');
container.style.width = `${items.length * 100}%`;


const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const nodemailer = require('nodemailer');
const transactionRoutes = require('./public/routes/transaction'); // Your route file

const app = express();

// === Middleware Setup ===
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

// === Nodemailer Route ===
app.post('/contact', (req, res) => {
  const { name, email, message } = req.body;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'mi.designs803@gmail.com',
      pass: 'your_gmail_app_password', // Use Gmail app password!
    },
  });

  const mailOptions = {
    from: email,
    to: 'mi.designs803@gmail.com',
    subject: 'New Contact Form Submission',
    text: `Name: ${name}\nEmail: ${email}\nMessage:\n${message}`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
      res.status(500).send('Error sending message.');
    } else {
      res.redirect('/thank-you.html');
    }
  });
});

// === MySQL Connection ===
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Summer97!',
  database: 'MyBrandingExperience'
});

connection.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err.stack);
    return;
  }
  console.log('Connected to MySQL as ID', connection.threadId);
});

// === Custom Routes ===
app.use('/', transactionRoutes);

// === Start Server ===
const PORT = process.env.PORT || 5500;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

module.exports = connection;

